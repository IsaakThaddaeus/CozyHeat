/**
* Copyright (c) 2010-2023 Contributors to the openHAB project
*
* See the NOTICE file(s) distributed with this work for additional
* information.
*
* This program and the accompanying materials are made available under the
* terms of the Eclipse Public License 2.0 which is available at
* http://www.eclipse.org/legal/epl-2.0
*
* SPDX-License-Identifier: EPL-2.0
*/

package org.openhab.automation.jrule.generated.items;

/**
* Automatically Generated Enum for ItemNames - DO NOT EDIT!
*
* @author Robert Delbrück - Initial
*/
public class JRuleItemNames {
    /**
     * Name: InfrarotheizungItem
     * <br/>
     * Type: Switch
     * <br/>
     * Label: InfrarotheizungItemP1P2B
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static final String InfrarotheizungItem = "InfrarotheizungItem";
    /**
     * Name: IntervallUeberpruefung
     * <br/>
     * Type: Number
     * <br/>
     * Label: IntervallUeberpruefungP1P2B
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static final String IntervallUeberpruefung = "IntervallUeberpruefung";
    /**
     * Name: LZaktivierung
     * <br/>
     * Type: Number
     * <br/>
     * Label: LZaktivierungP1P2B
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static final String LZaktivierung = "LZaktivierung";
    /**
     * Name: PauseDeaktivierung
     * <br/>
     * Type: Number
     * <br/>
     * Label: PauseDeaktivierungP1P2B
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static final String PauseDeaktivierung = "PauseDeaktivierung";
    /**
     * Name: Shelly25PMKanal0
     * <br/>
     * Type: String
     * <br/>
     * Label: Shelly25PMKanal0P1
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static final String Shelly25PMKanal0 = "Shelly25PMKanal0";
    /**
     * Name: StromerzeugungsintervalltimerVorhanden
     * <br/>
     * Type: String
     * <br/>
     * Label: StromerzeugungsintervalltimerVorhandenP1P2
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static final String StromerzeugungsintervalltimerVorhanden = "StromerzeugungsintervalltimerVorhanden";
    /**
     * Name: TimerBefehl
     * <br/>
     * Type: String
     * <br/>
     * Label: TimerBefehlP1P2
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static final String TimerBefehl = "TimerBefehl";
    /**
     * Name: TimerMenge
     * <br/>
     * Type: Number
     * <br/>
     * Label: TimerMengeP1P2
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static final String TimerMenge = "TimerMenge";
    /**
     * Name: UberhitzungsBoolean
     * <br/>
     * Type: Switch
     * <br/>
     * Label: UberhitzungsBooleanP1P2
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static final String UberhitzungsBoolean = "UberhitzungsBoolean";
    /**
     * Name: WattGrenzeFuerAktivierung
     * <br/>
     * Type: Number
     * <br/>
     * Label: WattGrenzeFuerAktivierungP1P2B
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static final String WattGrenzeFuerAktivierung = "WattGrenzeFuerAktivierung";
    /**
     * Name: produzierterStrom
     * <br/>
     * Type: Number
     * <br/>
     * Label: produzierterStromP1P2
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static final String produzierterStrom = "produzierterStrom";
}

