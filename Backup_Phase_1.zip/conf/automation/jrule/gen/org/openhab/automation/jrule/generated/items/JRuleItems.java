/**
* Copyright (c) 2010-2023 Contributors to the openHAB project
*
* See the NOTICE file(s) distributed with this work for additional
* information.
*
* This program and the accompanying materials are made available under the
* terms of the Eclipse Public License 2.0 which is available at
* http://www.eclipse.org/legal/epl-2.0
*
* SPDX-License-Identifier: EPL-2.0
*/

package org.openhab.automation.jrule.generated.items;

import org.openhab.automation.jrule.items.JRuleItemRegistry;
import org.openhab.automation.jrule.exception.JRuleItemNotFoundException;

import org.openhab.automation.jrule.internal.items.JRuleInternalSwitchItem;
import org.openhab.automation.jrule.items.JRuleSwitchItem;
import org.openhab.automation.jrule.internal.items.JRuleInternalNumberItem;
import org.openhab.automation.jrule.items.JRuleNumberItem;
import org.openhab.automation.jrule.internal.items.JRuleInternalNumberItem;
import org.openhab.automation.jrule.items.JRuleNumberItem;
import org.openhab.automation.jrule.internal.items.JRuleInternalNumberItem;
import org.openhab.automation.jrule.items.JRuleNumberItem;
import org.openhab.automation.jrule.internal.items.JRuleInternalStringItem;
import org.openhab.automation.jrule.items.JRuleStringItem;
import org.openhab.automation.jrule.internal.items.JRuleInternalStringItem;
import org.openhab.automation.jrule.items.JRuleStringItem;
import org.openhab.automation.jrule.internal.items.JRuleInternalStringItem;
import org.openhab.automation.jrule.items.JRuleStringItem;
import org.openhab.automation.jrule.internal.items.JRuleInternalNumberItem;
import org.openhab.automation.jrule.items.JRuleNumberItem;
import org.openhab.automation.jrule.internal.items.JRuleInternalSwitchItem;
import org.openhab.automation.jrule.items.JRuleSwitchItem;
import org.openhab.automation.jrule.internal.items.JRuleInternalNumberItem;
import org.openhab.automation.jrule.items.JRuleNumberItem;
import org.openhab.automation.jrule.internal.items.JRuleInternalNumberItem;
import org.openhab.automation.jrule.items.JRuleNumberItem;

/**
* Automatically Generated Class for Items - DO NOT EDIT!
*
* @author Arne Seime - Refactoring
* @author Robert Delbrück - Refactoring
*/
public class JRuleItems {



    /**
     * Name: InfrarotheizungItem
     * <br/>
     * Type: Switch
     * <br/>
     * Label: InfrarotheizungItemP1P2B
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static JRuleSwitchItem InfrarotheizungItem;

    /**
     * Name: IntervallUeberpruefung
     * <br/>
     * Type: Number
     * <br/>
     * Label: IntervallUeberpruefungP1P2B
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static JRuleNumberItem IntervallUeberpruefung;

    /**
     * Name: LZaktivierung
     * <br/>
     * Type: Number
     * <br/>
     * Label: LZaktivierungP1P2B
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static JRuleNumberItem LZaktivierung;

    /**
     * Name: PauseDeaktivierung
     * <br/>
     * Type: Number
     * <br/>
     * Label: PauseDeaktivierungP1P2B
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static JRuleNumberItem PauseDeaktivierung;

    /**
     * Name: Shelly25PMKanal0
     * <br/>
     * Type: String
     * <br/>
     * Label: Shelly25PMKanal0P1
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static JRuleStringItem Shelly25PMKanal0;

    /**
     * Name: StromerzeugungsintervalltimerVorhanden
     * <br/>
     * Type: String
     * <br/>
     * Label: StromerzeugungsintervalltimerVorhandenP1P2
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static JRuleStringItem StromerzeugungsintervalltimerVorhanden;

    /**
     * Name: TimerBefehl
     * <br/>
     * Type: String
     * <br/>
     * Label: TimerBefehlP1P2
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static JRuleStringItem TimerBefehl;

    /**
     * Name: TimerMenge
     * <br/>
     * Type: Number
     * <br/>
     * Label: TimerMengeP1P2
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static JRuleNumberItem TimerMenge;

    /**
     * Name: UberhitzungsBoolean
     * <br/>
     * Type: Switch
     * <br/>
     * Label: UberhitzungsBooleanP1P2
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static JRuleSwitchItem UberhitzungsBoolean;

    /**
     * Name: WattGrenzeFuerAktivierung
     * <br/>
     * Type: Number
     * <br/>
     * Label: WattGrenzeFuerAktivierungP1P2B
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static JRuleNumberItem WattGrenzeFuerAktivierung;

    /**
     * Name: produzierterStrom
     * <br/>
     * Type: Number
     * <br/>
     * Label: produzierterStromP1P2
     * <br/>
     * Tags: 
     * <br/>
     * Metadata: 
     */
 public static JRuleNumberItem produzierterStrom;


 static {
   loadItems();
 }

  /**
  * Need this method for testing
  */
 private static void loadItems() throws JRuleItemNotFoundException {
     InfrarotheizungItem = JRuleItemRegistry.get("InfrarotheizungItem", JRuleInternalSwitchItem.class);

     IntervallUeberpruefung = JRuleItemRegistry.get("IntervallUeberpruefung", JRuleInternalNumberItem.class);

     LZaktivierung = JRuleItemRegistry.get("LZaktivierung", JRuleInternalNumberItem.class);

     PauseDeaktivierung = JRuleItemRegistry.get("PauseDeaktivierung", JRuleInternalNumberItem.class);

     Shelly25PMKanal0 = JRuleItemRegistry.get("Shelly25PMKanal0", JRuleInternalStringItem.class);

     StromerzeugungsintervalltimerVorhanden = JRuleItemRegistry.get("StromerzeugungsintervalltimerVorhanden", JRuleInternalStringItem.class);

     TimerBefehl = JRuleItemRegistry.get("TimerBefehl", JRuleInternalStringItem.class);

     TimerMenge = JRuleItemRegistry.get("TimerMenge", JRuleInternalNumberItem.class);

     UberhitzungsBoolean = JRuleItemRegistry.get("UberhitzungsBoolean", JRuleInternalSwitchItem.class);

     WattGrenzeFuerAktivierung = JRuleItemRegistry.get("WattGrenzeFuerAktivierung", JRuleInternalNumberItem.class);

     produzierterStrom = JRuleItemRegistry.get("produzierterStrom", JRuleInternalNumberItem.class);

 }

}

