Your item definitions go here.
All items files have to have the ".items" file extension and must follow a special syntax.

Check out the openHAB documentation for more details:
https://www.openhab.org/docs/configuration/items.html
